var http = require('http');
let server = http.createServer((req,res)=>{
    if(req.url=='/product'){
        res.write("<h1>{'name':'iPhone', 'brand': 'Apple'}</h1>");
        res.end();
    }else if(req.url=='/user'){
        res.write("<h1>{'name':'Sumeet', 'Desg': 'ASE'}</h1>");
        res.end();
    }else{
        res.write("<h1>Home</h1>");
        res.end();
    }

});

server.listen(4500,()=>console.log("Server Started..."));