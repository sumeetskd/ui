var http = require('http');
let server = http.createServer((req,res)=>{
    res.write("Hello welcome to Node");
    res.end();
});

server.listen(4500,()=>console.log("Server started at port 4500"));