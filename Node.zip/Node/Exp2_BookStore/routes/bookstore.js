var express = require('express');
var router = express.Router();
var bookData = require('./books.json');

router.get('/', (req, res) => {
    res.send("Bookstore Home Page");
});

router.get('/allBooks', (req, res) => {
    res.send(bookData);
});

router.get('/title/:booktitle', (req, res) => {
    var titleToSearch = req.params.booktitle;
    const book = bookData.find((item) => item.title == titleToSearch);
    // res.send(book);
    if (book) {
        console.log(book + " Book Found");
        res.send(book);
    } else {
        res.status(404).send("Book Not Found " + book);
    }
});

router.get('/author',(req,res)=>{
    const bookWithAuthor = bookData.filter((item)=>item.authors.find((atitle)=>atitle==req.query.authorname));
    if(bookWithAuthor.length>0){
        res.send(bookWithAuthor);
    }else{
        //404 for client's error
        res.status(404).send("Book with author name "+req.query.authorname+" is not found");
    }
});
//localhost:3000/book/author?authorname=John

router.post('/',(req,res)=>{
    //record old length
    var oldlen = bookData.length;
    //make changes in body, and push
    bookData.push(req.body);
    //record new length
    var newlen = bookData.length;
    //logic
    if(newlen>oldlen){
        res.send("Data added successfully");
    }else{
        //500 for server's error
        res.status(500).send("Server Error. Unable to make changes.");
    }
});

router.delete('/',(req,res)=>{
    var titleToBeDeleted = bookData.find((item)=>item.title==req.body.title);
    if(titleToBeDeleted){
        bookData = bookData.filter((item)=>item.title!=req.body.title);
        res.send("Book Deleted with title "+req.book.title);
    }else{
        res.status(404).send("No book fond to delete with tile: "+req.body.tilte);
    }
});


module.exports = router;