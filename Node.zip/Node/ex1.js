var fs = require('fs');

fs.readFile('./data.json','utf-8', function(err,data){
    console.log("Read File:");

    //error first callback function
    // err(1st param)->hold the error if any 
    // data(2nd param)-> hold the data from file
    if(err){
        //error block
        console.log("Error has occured: "+err);
    }else{
        mydata = JSON.parse(data);
        // will parse the json data into object
        console.log(mydata.name);

        // console.log(mydata);
    }
});
fs.writeFile('./mydata.txt','Hello World',function(err,data){
    console.log("Write:");

    if(err){
        console.log("Error");
    }else{
       
        console.log("File Created Successfully");
    }
});
var content = "New Content Added";

fs.appendFile('./mydata.txt',content,function(err,data){
    console.log("Append:");

    if(err){
        console.log("An Error has Occured: "+err);
    }else{
        console.log("File appended Successfully. ");
    }
});