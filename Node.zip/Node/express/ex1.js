var express=require('express');


const app = express();
const port = 4000;

app.get('/',(req,res)=>{
    res.send("Welcome to Express");
});

app.get('/user',(req,res)=>{
    res.send("This is User Page");
});

app.get('/product',(req,res)=>{
    res.send("This is for Product Page");
});

app.post('/',(req,res)=>{

});

app.listen(port,()=>console.log("Server:4000 started.."));
