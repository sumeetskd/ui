var http = require('http');
var fs = require('fs');
var path = './greeting.txt';

let server = http.createServer((req,res)=>{
    if(req.url=="/"){
        res.write("Node Server is up and running!");
        res.end();
    }
    else if(req.url=='/greet'){
        var r_file;
        fs.readFile(path,'utf-8',(err,data)=>{
            if(err){
                console.log("An Error has occured");
                res.write("An Error has occured");
                res.end();
            }else{

                r_file = data;
                console.log("File recieved");
                res.write(r_file);
                res.end();

            }
            
    });
    }else{
        console.log("Url not found");
        var k = res.status(404);
        res.write(k+" Invalid Router");
        res.end();
    }
});

server.listen(4000,()=>console.log("Server Started at port:4000..."));