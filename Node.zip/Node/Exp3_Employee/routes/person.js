var express = require('express');
var router = express.Router();
var personData = require('./data.json');

router.get('/',(req,res)=>{
    res.send('Person HomePage');
    // console.log()
});

router.get('/allperson',(req,res)=>{
    res.send(personData);
});

router.get('/allperson/:pid', (req, res)=>{
    var idToSearch = req.params.pid;
    const pData = personData.find((item)=>item.id==idToSearch);
    console.log("Person Found: "+pdata);
    if(pData){
        res.send(pData);
    }else{
        res.status(404).send("Person ID not found..");
    }

});

module.exports = router;